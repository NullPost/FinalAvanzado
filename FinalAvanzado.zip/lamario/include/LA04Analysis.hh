/* 
 * LA04Analysis.hh: Header para la clase
 * LA04Analysis.
 * 
 * Archivo de ejemplo de Geant4 para la unidad 3
 * del curso de Laboratorio Avanzado ECFM-USAC
 * 
 * Héctor Pérez
 * abril 2021
 * 
 * Basado en el ejemplo B1 y B4 de Geant4.10.06.p03
 */

#ifndef LA04Analysis_h
#define LA04Analysis_h 1
#include "g4root.hh"
//#include "g4xml.hh"
//#include "g4csv.hh"
//#include "g4hdf5.hh"
#endif